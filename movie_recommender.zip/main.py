import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# === Step 1: Load dataset ===
df = pd.read_csv('movie_summaries.csv')  
df = df[['movie_title', 'plot_summary']].dropna()
df['title_lower'] = df['movie_title'].str.lower()

# === Step 2: Vectorize plot summaries ===
vectorizer = TfidfVectorizer(stop_words='english', max_features=50000)
tfidf_matrix = vectorizer.fit_transform(df['plot_summary'])

# === Step 3: Compute cosine similarity matrix ===
cosine_sim = cosine_similarity(tfidf_matrix, tfidf_matrix)

# === Step 4: Build recommendation function ===
def recommend_movies(input_title, df=df, cosine_sim=cosine_sim):
    title = input_title.lower()
    if title not in df['title_lower'].values:
        return f"Movie '{input_title}' not found in dataset."
    idx = df[df['title_lower'] == title].index[0]
    sim_scores = list(enumerate(cosine_sim[idx]))
    sim_scores = sorted(sim_scores, key=lambda x: x[1], reverse=True)
    top_scores = sim_scores[1:6]
    results = [(df.iloc[i]['movie_title'], score) for i, score in top_scores]
    return results

# === Step 5: Run interactive prompt ===
if __name__ == '__main__':
    print("Enter a movie title:")
    user = input().strip()
    recs = recommend_movies(user)
    if isinstance(recs, str):
        print(recs)
    else:
        print(f"\nTop 5 movies similar to '{user}':")
        for title, score in recs:
            print(f"• {title} (similarity = {score:.3f})")
