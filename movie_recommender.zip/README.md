# Movie Recommender System (TF-IDF + Cosine Similarity)

This project recommends 5 movies based on a given movie title using TF-IDF vectorization of plot summaries.

## Requirements

- Python 3
- pandas
- scikit-learn

## Setup

1. Download the CMU Movie Summary Corpus and extract `movie_summaries.csv`:
   - [CMU Movie Dataset](https://www.cs.cmu.edu/~ark/personas/)
2. Place `movie_summaries.csv` in the project root folder.

## Run

```bash
python main.py
```

Enter a movie title when prompted to get 5 similar recommendations.
